# Invoice OCR System — Complete Function & Task Specification
**Version:** 2.0.0 | **Scope:** Every function, signature, purpose, inputs, outputs, edge-case behavior
**Image Context:** In-hand mobile phone photos of Vietnamese retail receipts with cluttered backgrounds

---

## Table of Contents
1. [Module Map](#1-module-map)
2. [API Layer — `src/api/`](#2-api-layer)
3. [Storage Clients — `src/storage/`](#3-storage-clients)
4. [Worker Orchestration — `src/worker/`](#4-worker-orchestration)
5. [AI Pipeline — `src/pipeline/`](#5-ai-pipeline)
6. [Schema & Models — `src/models/`](#6-schema--models)
7. [Background Tasks](#7-background-tasks)
8. [Custom Exception Hierarchy](#8-custom-exception-hierarchy)
9. [Function Dependency Graph](#9-function-dependency-graph)

---

## 1. Module Map

```
src/
├── api/
│   └── main.py                  # FastAPI router — POST /predict, GET /health, GET /metrics
├── storage/
│   ├── minio_client.py          # Blob upload, download, delete, move_to_failed
│   ├── postgres_client.py       # Job state persistence + zombie sweep
│   └── redis_client.py          # Queue LPUSH/BRPOP + RPC publish/wait
├── worker/
│   └── main.py                  # Consumer loop + task lifecycle orchestration
├── pipeline/
│   ├── image_processor.py       # PIL validation + EXIF orientation
│   ├── triton_client.py         # YOLO inference, NMS, crop (Triton gRPC)
│   ├── gemini_client.py         # LLM extraction with Vietnamese prompt
│   └── schema_parser.py         # Pydantic validation + VND number coercion
└── models/
    └── invoice.py               # InvoiceResult + LineItem Pydantic models
```

**Removed from v1.0:** `get_receipt_status_fallback()` — the `GET /predict/{job_id}` fallback endpoint has been eliminated. The single `POST /predict` is the complete client interface.

---

## 2. API Layer — `src/api/main.py`

---

### `generate_job_id()`

**Signature:**
```python
def generate_job_id() -> str
```

**Purpose:** Produces a universally unique, non-enumerable identifier for each job. Serves as the primary key in Postgres, the MinIO object key, and the Redis queue/result key suffix.

**Implementation:**
```python
import uuid
def generate_job_id() -> str:
    return str(uuid.uuid4())
```

**Returns:** `str` — UUID4 in hyphenated format, e.g. `"550e8400-e29b-41d4-a716-446655440000"`.

**Edge Cases:**
- UUID4 provides 122 bits of entropy. Collision across 10,000 daily jobs has probability ~1 in 10³⁰. No database uniqueness pre-check needed.
- Never use sequential or timestamp-based IDs. Sequential IDs allow one client to iterate through another client's job results.

---

### `health_check()`

**Signature:**
```python
@app.get("/health")
async def health_check() -> dict
```

**Purpose:** Shallow liveness probe for Docker healthcheck, load balancers, and orchestrators. Always returns `{"status": "ok"}` as long as the Python process is alive. Does **not** check Redis, Postgres, or MinIO — those are deep health and must not block this probe.

**Response:** `{"status": "ok"}` — always HTTP 200. Must respond in < 10ms.

**Edge Cases:**
- If Postgres is down, this endpoint must still return 200 so the container is not killed. Deep dependency health belongs at a separate `/health/deep` endpoint if ever needed.

---

### `metrics_endpoint()`

**Signature:**
```python
@app.get("/metrics")
async def metrics_endpoint() -> Response
```

**Purpose:** Prometheus scrape target. Called every 15 seconds by the Prometheus container. Powers all Grafana dashboards.

**Implementation:** `prometheus_client.generate_latest()` with `CONTENT_TYPE_LATEST` header.

**Metrics exposed:** See Architecture §8.1. Note: `ocr_queue_depth` gauge is updated here via `LLEN ocr_tasks`. If Redis is unreachable, log the error and return all other metrics — do not return HTTP 500, which would cause Prometheus to mark the target as DOWN and trigger false alerts.

---

### `submit_receipt(file: UploadFile)`

**Signature:**
```python
@app.post("/predict")
async def submit_receipt(file: UploadFile = File(...)) -> JSONResponse
```

**Purpose:** The complete client interface. Single synchronous entry point. Accepts an image of a Vietnamese receipt, orchestrates the Producer side of the pipeline (upload → record → enqueue), blocks for up to 60 seconds waiting for the Worker result, then returns the final JSON response. **This is the only endpoint the client ever calls.**

**Parameters:**
- `file: UploadFile` — Multipart image file. Expected: mobile phone JPEG/PNG of a Vietnamese receipt. Max size: `MAX_UPLOAD_SIZE_MB` (default 10MB), enforced by FastAPI middleware before this handler runs.

**Execution Steps & Edge Cases:**

| Step | Operation | Success | Failure & Response |
|---|---|---|---|
| 1 | `job_id = generate_job_id()` | UUID4 string | Never fails |
| 2 | `file_bytes = await file.read()` | Raw bytes | OOM prevented by middleware size limit |
| 3 | `minio.upload_file(job_id, file_bytes)` | MinIO path | `MinioConnectionError` → **HTTP 503** |
| 4 | `db.create_job_record(job_id)` | Row inserted | `DBConnectionError` → **HTTP 503**. MinIO blob orphaned — acceptable; cleanup cron handles stale blobs. |
| 5 | `redis.push_to_queue(job_id)` | LPUSH success | `RedisConnectionError` → **HTTP 503** |
| 6 | `result = redis.wait_for_result(job_id, timeout=60)` | `dict` received | `ResultTimeoutError` (60s elapsed) → **HTTP 504** |
| 7 | Check `result["success"]` | `True` → HTTP 200 | `False` → **HTTP 422** with error from Worker |
| 8 | Return `InvoiceResult` JSON | HTTP 200 | — |

**HTTP 200 Response Body:** `InvoiceResult` JSON (see §6).

**HTTP 422 Response Body:**
```json
{
  "job_id": "550e8400-...",
  "error": "NoReceiptDetectedError: confidence 0.28 below threshold 0.35"
}
```

**HTTP 504 Response Body:**
```json
{
  "job_id": "550e8400-...",
  "error": "Processing timeout — please retry"
}
```

**Metrics updated:** `ocr_requests_total` (with appropriate status label), `ocr_request_duration_seconds`.

---

## 3. Storage Clients — `src/storage/`

---

### MinIO Client — `src/storage/minio_client.py`

---

#### `upload_file(job_id, file_bytes)`

**Signature:**
```python
async def upload_file(job_id: str, file_bytes: bytes) -> str
```

**Purpose:** Persists the raw receipt image to MinIO before queueing. Decouples image storage from API RAM. At burst: 3 req/s × 60s timeout × 600KB = 108MB would otherwise sit in API memory.

**Parameters:**
- `job_id: str` — Used as the MinIO object key: `invoices/{job_id}.jpg`
- `file_bytes: bytes` — Raw bytes from the HTTP multipart upload

**Returns:** `str` — MinIO object path, e.g. `"invoices/550e8400-....jpg"`

**Edge Cases:**
- **Content-type detection removed in v2.0.** The v1.0 `python-magic` MIME check has been removed. PIL in the Worker is the authoritative image validator. This function accepts any bytes and stores them. Invalid images are caught downstream by `validate_and_orient_image()`.
- **MinIO offline:** Raises `MinioConnectionError`. API returns HTTP 503. No Postgres record has been written yet, so no zombie is created.
- **Object key collision:** UUID4 makes this astronomically unlikely. No pre-check needed.
- **Connection timeout:** Set SDK `connect_timeout=5s`, `read_timeout=15s`. Failure raises `MinioConnectionError`.

---

#### `download_file(job_id)`

**Signature:**
```python
async def download_file(job_id: str) -> bytes
```

**Purpose:** Retrieves the raw image bytes for the Worker pipeline. Called as the first step of `execute_task_lifecycle()`.

**Returns:** `bytes` — Raw image bytes.

**Edge Cases:**
- **Object not found:** Should never occur in normal flow (upload precedes LPUSH). Can occur if MinIO data was manually deleted or the bucket was wiped. Raises Python `FileNotFoundError`. Worker's `except Exception` block catches it → job marked FAILED.
- **Corrupted partial download:** Validate that received byte length matches MinIO object size header. Mismatch → raises `CorruptedDownloadError`.
- **MinIO offline:** Raises `MinioConnectionError` → Worker catches → FAILED path.

---

#### `delete_file(job_id)`

**Signature:**
```python
async def delete_file(job_id: str) -> None
```

**Purpose:** Garbage collection. Deletes the raw image from `invoices/` after successful extraction. Called **after** `redis.publish_result()` in the SUCCESS path — this order is critical. Without deletion: 10,000 jobs/day × 600KB = 6GB/day permanent accumulation.

**Critical Ordering (v2.0 fix):**
```python
# CORRECT order — cleanup must never block the result return path
await redis.publish_result(job_id, result, success=True)  # unblock API first
await minio.delete_file(job_id)                           # then clean up
```

**Edge Cases:**
- **Object not found (already deleted):** MinIO returns 204 for deletes of non-existent keys. Treated as success — idempotent.
- **MinIO offline:** Log warning with `job_id`. Do **not** raise or re-raise. The extraction already succeeded and the result has already been published to Redis. The orphaned blob will be swept by a periodic MinIO cleanup cron that finds objects in `invoices/` older than 1 hour whose `job_id` has status SUCCESS in Postgres.
- **Exception in delete_file must never propagate.** Wrap the call in a secondary try/except in `execute_task_lifecycle()` so that a delete failure cannot trigger the FAILED path on a job that succeeded.

---

#### `move_to_failed(job_id)`

**Signature:**
```python
async def move_to_failed(job_id: str) -> None
```

**Purpose:** On pipeline failure, moves the problematic image to `failed_invoices/` for developer post-mortem. Enables root-cause analysis of YOLO false rejections, Gemini hallucinations, or VND parse failures specific to certain receipt formats.

**Implementation:**
```python
# MinIO SDK has no native move — copy then delete
await client.copy_object(
    source_bucket="invoices",       source_key=f"{job_id}.jpg",
    dest_bucket="failed-invoices",  dest_key=f"{job_id}.jpg"
)
await client.delete_object(bucket="invoices", key=f"{job_id}.jpg")
```

**Edge Cases:**
- **Source object missing:** Log warning and skip. The FAILED status and traceback in Postgres is the primary failure record.
- **Copy succeeds, delete fails:** Object exists in both buckets. Acceptable (duplication, not loss). The cleanup cron will deduplicate.
- **`failed_invoices/` bucket full or permission error:** Log at ERROR level. Do not raise — the Postgres FAILED record is the authoritative failure marker.
- **PII note:** Vietnamese retail receipts in `failed_invoices/` may contain customer names, phone numbers (e.g. "SĐT ******3173"), and purchase history. This bucket must be restricted to engineers with explicit need-to-know.

---

### Postgres Client — `src/storage/postgres_client.py`

---

#### `create_job_record(job_id)`

**Signature:**
```python
async def create_job_record(job_id: str) -> None
```

**Purpose:** Inserts the initial job row with `status='PENDING'`. This is the authoritative record of a job's existence. If this write fails, the job does not exist from the system's perspective.

**SQL:**
```sql
INSERT INTO jobs (job_id, status, created_at, updated_at)
VALUES ($1, 'PENDING', NOW(), NOW());
```

**Edge Cases:**
- **Postgres offline:** `DBConnectionError` → API returns HTTP 503. The MinIO blob uploaded in the previous step is now orphaned. A periodic MinIO cleanup cron finds blobs in `invoices/` with no corresponding Postgres `job_id` and deletes them.
- **Connection pool exhausted:** Configure `asyncpg` pool: `min_size=2, max_size=10`. Pool exhaustion at burst (3 req/s) is unlikely — the API BRPOP blocks for seconds before the next query, keeping pool usage low.
- **Command timeout:** Set `command_timeout=5s`.

---

#### `update_job_status(job_id, status, result_payload=None, error_log=None)`

**Signature:**
```python
async def update_job_status(
    job_id: str,
    status: str,
    result_payload: dict | None = None,
    error_log: str | None = None
) -> None
```

**Purpose:** Transitions a job's status and optionally writes the result payload or error traceback. Called at every state transition.

**Valid transitions:**
- `PENDING → PROCESSING` (Worker picks up job)
- `PROCESSING → SUCCESS` (Worker completes successfully)
- `PROCESSING → FAILED` (Worker pipeline error)

**SQL:**
```sql
UPDATE jobs
SET status         = $2,
    result_payload = $3,
    error_log      = $4,
    updated_at     = NOW()
WHERE job_id = $1;
```

**Edge Cases:**
- **Postgres offline during PROCESSING → SUCCESS update:** Log error. `redis.publish_result()` should still be attempted — the client may receive the result synchronously even if Postgres doesn't record it. The `result_payload` in Postgres is only an audit trail; the real-time result delivery is via Redis.
- **Status validation:** Validate against `{'PROCESSING', 'SUCCESS', 'FAILED'}` before executing SQL. Raise `ValueError` on invalid input — this is a programming error, not a runtime error.
- **`error_log` truncation:** Tracebacks can be long. If > 10,000 chars, truncate to `error_log[:10000] + "...[truncated]"` before inserting to avoid TOAST bloat.

---

#### `get_job_record(job_id)` — kept for internal use only

**Signature:**
```python
async def get_job_record(job_id: str) -> JobRecord | None
```

**Purpose:** Retrieves a job record. Used internally by `sweep_zombie_jobs()` and any operational tooling. **Not exposed via API** (the v1.0 fallback GET endpoint has been removed).

**Returns:** `JobRecord` dataclass or `None` if not found.

---

#### `mark_zombie_jobs_failed()` — renamed from v1.0's `sweep_zombie_jobs()`

**Signature:**
```python
async def mark_zombie_jobs_failed() -> dict[str, int]
```

**Purpose:** Finds jobs stuck in either `PROCESSING` (worker crashed) or `PENDING` (Redis failure between enqueue and BRPOP) beyond their threshold times and transitions them to `FAILED`. Runs every 5 minutes via APScheduler.

**Returns:** `dict` — `{"processing_swept": N, "pending_swept": M}` — used to update `ocr_zombie_jobs_swept_total` metric with the `from_status` label.

**SQL (v2.0 — covers both states):**
```sql
WITH swept AS (
    UPDATE jobs
    SET status    = 'FAILED',
        error_log = CASE
            WHEN status = 'PROCESSING'
                THEN 'Zombie: worker did not complete within 15 minutes'
            WHEN status = 'PENDING'
                THEN 'Zombie: job not picked up within 30 minutes (possible Redis failure)'
        END,
        updated_at = NOW()
    WHERE (
        (status = 'PROCESSING' AND updated_at < NOW() - INTERVAL '15 minutes')
     OR (status = 'PENDING'    AND updated_at < NOW() - INTERVAL '30 minutes')
    )
    RETURNING job_id, status AS original_status
)
SELECT original_status, COUNT(*) AS swept_count
FROM swept
GROUP BY original_status;
```

**Edge Cases:**
- **Race condition — Worker completes just after PENDING sweep:** The sweep sets status to FAILED. The Worker (if it somehow resumed from a Redis recovery) will call `update_job_status(SUCCESS)`, which overwrites FAILED → SUCCESS. The Worker also calls `publish_result(success=True)`, which the API (if still waiting) will receive. This is the correct outcome — the Worker's result is authoritative.
- **Race condition — Sweep marks PROCESSING as FAILED, Worker finishes a moment later:** Same as above. Worker overwrites FAILED → SUCCESS. The client receives the correct result.
- **Threshold calibration:** PROCESSING threshold 15 min vs. max pipeline time ~45s. PENDING threshold 30 min vs. max queue time ~2s at burst. Both thresholds are conservatively safe — no legitimate job should hit them.

---

### Redis Client — `src/storage/redis_client.py`

---

#### `push_to_queue(job_id)`

**Signature:**
```python
async def push_to_queue(job_id: str) -> None
```

**Purpose:** Enqueues a job for any of the 4 Workers to pick up. Uses `LPUSH` so items pile up on the left; Workers use `BRPOP` which pops from the right — FIFO ordering.

**Implementation:**
```python
await redis.lpush("ocr_tasks", job_id)
```

**Edge Cases:**
- **Redis offline:** `RedisConnectionError` → HTTP 503. Postgres record exists in PENDING state. If Redis comes back up, the zombie PENDING sweep will eventually FAIL these jobs (after 30 min). Client should retry POST /predict.
- **Backpressure (optional enhancement):** If `LLEN ocr_tasks > 100`, consider returning HTTP 429 (Too Many Requests) to signal overload. Not implemented by default but recommend adding as a safety valve.

---

#### `wait_for_result(job_id, timeout=60)`

**Signature:**
```python
async def wait_for_result(job_id: str, timeout: int = 60) -> dict
```

**Purpose:** Blocks the API request handler, waiting for the Worker to publish the result. This is the synchronous RPC mechanism — the API "calls" the Worker and waits for the "return value" via Redis.

**Implementation:**
```python
result = await redis.brpop(f"result_{job_id}", timeout=timeout)
if result is None:
    raise ResultTimeoutError(f"No result for {job_id} within {timeout}s")
return json.loads(result[1])
```

**Returns:** `dict` with keys:
- `"success": bool`
- `"payload": dict` (InvoiceResult) if `success=True`
- `"error": str` if `success=False`

**Edge Cases:**
- **Timeout after 60s:** `BRPOP` returns `None`. Raises `ResultTimeoutError`. API returns HTTP 504. The Worker **continues running** — it will still complete and publish the result to the (now-expired-TTL) key. Since the client received 504, they will retry POST /predict. The second request creates a new job_id and starts fresh. The old result key expires in 90s.
- **Client disconnects while BRPOP is blocking:** FastAPI cancels the async task. The Redis connection is released. The Worker completes and LPUSH's the result. The 90s TTL auto-cleans the orphaned key.
- **Worker publishes `success=False`:** `result["success"]` is False. API returns HTTP 422 with the error string. Job status in Postgres is FAILED. Client should not retry the same image without modification (the image itself caused the failure — e.g., YOLO couldn't find the receipt).
- **`result[1]` is malformed JSON:** Should never occur — Workers always serialize via `json.dumps`. If it does, catch `JSONDecodeError` → return HTTP 500.

---

#### `pop_from_queue()`

**Signature:**
```python
async def pop_from_queue() -> str
```

**Purpose:** Worker-side queue pop. Blocks indefinitely until a job is available. `timeout=0` means block forever — no spinning, no polling overhead. All 4 Workers simultaneously block here between jobs.

**Implementation:**
```python
result = await redis.brpop("ocr_tasks", timeout=0)
return result[1].decode("utf-8")
```

**Edge Cases:**
- **Redis restarts while BRPOP is blocking:** Connection drops → `RedisConnectionError`. The Worker's outer loop catches this, waits 5s, then reconnects and calls `pop_from_queue()` again.
- **Duplicate job_id in queue:** Should not occur (one LPUSH per POST). If it does (manual re-queue by operations team), the Worker checks job status before proceeding: if status is already `SUCCESS` or `FAILED`, skip and log. Only process jobs in `PENDING` status.

---

#### `publish_result(job_id, result_payload, success)`

**Signature:**
```python
async def publish_result(
    job_id: str,
    result_payload: dict | str,
    success: bool
) -> None
```

**Purpose:** Worker pushes the final result (or error) back to the waiting API via the per-job Redis key. Unblocks the API's `wait_for_result()` BRPOP. Immediately sets a 90-second TTL on the result key using an atomic pipeline to prevent RAM leakage.

**Parameters:**
- `result_payload: dict | str` — On success: `InvoiceResult` dict. On failure: the exception message string.
- `success: bool` — Signals to API: True → HTTP 200, False → HTTP 422.

**Implementation (atomic pipeline):**
```python
payload = json.dumps({"success": success, "payload": result_payload})
pipe = redis.pipeline()
pipe.lpush(f"result_{job_id}", payload)
pipe.expire(f"result_{job_id}", 90)  # 90s TTL — outlasts the 60s API timeout
await pipe.execute()
```

**Why an atomic pipeline for LPUSH + EXPIRE?** If the process crashes between LPUSH and EXPIRE, the key leaks permanently. The pipeline batches both commands in a single network roundtrip and executes them atomically at the Redis level. 10,000 jobs/day × 2KB per key × no TTL = ~20MB/day permanent RAM leak prevented.

**Edge Cases:**
- **Redis offline when Worker tries to publish:** The Worker has already updated Postgres to SUCCESS and (in the FAILED path) moved the image. The API is still blocking on BRPOP (or has already timed out at 60s → 504). If LPUSH fails: the Postgres record has the authoritative status. Client must retry POST /predict. Log at ERROR level with full context.
- **API already timed out before publish:** LPUSH succeeds but the API's BRPOP has already returned None and the API sent HTTP 504. Key is created with 90s TTL, then auto-evicted. No action needed.

---

## 4. Worker Orchestration — `src/worker/main.py`

---

### `start_worker_loop()`

**Signature:**
```python
def start_worker_loop() -> None
```

**Purpose:** Main entry point for each of the 4 Worker containers. Runs forever, popping and processing jobs. Also starts the APScheduler background scheduler for zombie sweeps. Designed to survive any exception without exiting.

**Implementation:**
```python
def start_worker_loop():
    scheduler = BackgroundScheduler()
    scheduler.add_job(
        run_zombie_sweep,
        trigger=IntervalTrigger(minutes=int(ZOMBIE_SWEEP_INTERVAL_MINUTES)),
        id="zombie_sweep",
        max_instances=1  # prevent overlap if sweep takes long
    )
    scheduler.start()

    logger.info("Worker started", extra={"worker_id": WORKER_ID})

    while True:
        try:
            job_id = asyncio.run(redis.pop_from_queue())
            # Guard: skip jobs already processed (handles duplicate LPUSH)
            record = asyncio.run(db.get_job_record(job_id))
            if record and record.status != 'PENDING':
                logger.warning("Skipping non-PENDING job", extra={"job_id": job_id, "status": record.status})
                continue
            asyncio.run(execute_task_lifecycle(job_id))
        except RedisConnectionError as e:
            logger.error("Redis connection lost, retrying in 5s", extra={"error": str(e)})
            time.sleep(5)
        except Exception as e:
            logger.critical("Unhandled error in worker loop", exc_info=True)
            # Do NOT re-raise — keep the loop alive
```

**Edge Cases:**
- **Redis drops mid-loop:** `pop_from_queue()` raises. Outer loop catches `RedisConnectionError`, waits 5s, retries. Container stays up.
- **`execute_task_lifecycle` leaks an unhandled exception:** Should never happen (lifecycle wraps everything in try/except), but if it does, the critical-level log triggers a Grafana alert. The loop continues — no container restart.
- **Single-threaded by design:** One job processed at a time per container. This is intentional — Gemini API latency dominates, and running multiple jobs per Worker would not improve throughput but would increase Gemini concurrency. Horizontal scaling via 4 containers is the correct approach.
- **`WORKER_ID`:** Set from the Docker hostname environment variable for log correlation. Allows tracing a specific job failure to a specific worker container in Grafana.

---

### `run_zombie_sweep()` — APScheduler wrapper

**Signature:**
```python
def run_zombie_sweep() -> None
```

**Purpose:** Scheduler wrapper around `db.mark_zombie_jobs_failed()`. Runs every 5 minutes. Updates Prometheus counters with sweep results. Separated from the DB function by naming to avoid the v1.0 naming collision.

**Implementation:**
```python
def run_zombie_sweep():
    results = asyncio.run(db.mark_zombie_jobs_failed())
    processing_count = results.get("PROCESSING", 0)
    pending_count = results.get("PENDING", 0)
    if processing_count:
        logger.warning("Zombie PROCESSING jobs swept", extra={"count": processing_count})
        ocr_zombie_jobs_swept_total.labels(from_status="PROCESSING").inc(processing_count)
    if pending_count:
        logger.warning("Zombie PENDING jobs swept", extra={"count": pending_count})
        ocr_zombie_jobs_swept_total.labels(from_status="PENDING").inc(pending_count)
```

---

### `execute_task_lifecycle(job_id)`

**Signature:**
```python
async def execute_task_lifecycle(job_id: str) -> None
```

**Purpose:** Safety harness for a single job. Guarantees that regardless of what happens in the AI pipeline, the job always ends in SUCCESS or FAILED, the result is always published to Redis, and the MinIO blob is always handled. No job can be silently abandoned.

**Corrected operation order (v2.0):**
```python
async def execute_task_lifecycle(job_id: str) -> None:
    await db.update_job_status(job_id, 'PROCESSING')

    try:
        image_bytes = await minio.download_file(job_id)
        oriented    = image_processor.validate_and_orient_image(image_bytes)
        bbox        = triton_client.detect_receipt_bounding_box(oriented)
        cropped     = triton_client.crop_image(oriented, bbox)
        raw_json    = await gemini_client.extract_invoice_data(cropped)
        result      = schema_parser.validate_extracted_schema(raw_json)

        await db.update_job_status(job_id, 'SUCCESS', result_payload=result.dict())
        await redis.publish_result(job_id, result.dict(), success=True)  # ← FIRST
        try:
            await minio.delete_file(job_id)                              # ← AFTER, isolated
        except Exception as cleanup_err:
            logger.warning("delete_file failed after SUCCESS", extra={
                "job_id": job_id, "error": str(cleanup_err)
            })  # Do not re-raise — result already returned

    except Exception as e:
        error_trace = traceback.format_exc()
        logger.error("Job FAILED", extra={"job_id": job_id, "error": str(e)})
        await db.update_job_status(job_id, 'FAILED', error_log=error_trace[:10000])
        await redis.publish_result(job_id, str(e), success=False)
        try:
            await minio.move_to_failed(job_id)
        except Exception as move_err:
            logger.warning("move_to_failed failed", extra={"job_id": job_id, "error": str(move_err)})
```

**Stage timing:** Each stage is timed and logged as `pipeline_stage_complete` event. Times are also recorded in `ocr_worker_pipeline_duration_seconds` histogram with the stage label for Grafana Panel 9.

---

## 5. AI Pipeline — `src/pipeline/`

---

### `validate_and_orient_image(image_bytes)` — `image_processor.py`

**Signature:**
```python
def validate_and_orient_image(image_bytes: bytes) -> bytes
```

**Purpose:** Validates that the bytes are a decodable image, applies EXIF auto-rotation (critical for mobile phone photos — iPhones and Android devices frequently upload rotated JPEGs), converts to normalized RGB JPEG for consistent Triton preprocessing.

**Returns:** `bytes` — EXIF-corrected RGB JPEG at quality=95.

**Implementation steps:**
1. `PIL.Image.open(BytesIO(image_bytes))` — raises `InvalidImageError` if not decodable
2. `ImageOps.exif_transpose(img)` — applies EXIF rotation (no-op if absent)
3. `img.convert("RGB")` — removes alpha (PNG), normalizes color space
4. Resize check: if `max(img.width, img.height) > 8000` → resize long edge to 4096px (prevents memory spike on high-res camera photos)
5. Re-encode as JPEG quality=95
6. Return bytes

**Edge Cases (specific to Vietnamese in-hand mobile photos):**
- **iPhone portrait photo with EXIF rotation=6:** PIL reads as landscape (raw sensor orientation). `exif_transpose` corrects to portrait. Without this, YOLO sees a sideways receipt and fails.
- **PDF uploaded instead of image:** PIL raises `UnidentifiedImageError`. Caught → `InvalidImageError("File is not a valid image")`. Saves Gemini API cost.
- **Corrupted JPEG (truncated upload):** PIL raises `OSError: image file is truncated`. Caught → `InvalidImageError("Corrupted image")`.
- **High-res camera photo (50MP):** Some newer phones produce 8000×6000 images. PIL will open them but the Triton preprocessing tensor would be huge. Resize to 4096px on long edge. The receipt is a small fraction of the frame so downsampling retains all readable text.
- **Very dark or blurry photo:** PIL decodes successfully. `validate_and_orient_image` does not reject based on image quality — that is YOLO's job (low confidence score).

---

### `detect_receipt_bounding_box(image_bytes)` — `triton_client.py`

**Signature:**
```python
def detect_receipt_bounding_box(image_bytes: bytes) -> tuple[float, float, float, float]
```

**Purpose:** Sends the preprocessed image to YOLOv11n via Triton gRPC. Returns the bounding box of the receipt in the original image's coordinate space, after NMS and confidence filtering. This isolates the receipt from the hand, groceries, and background before sending to Gemini.

**Returns:** `(x1, y1, x2, y2)` — pixel coordinates in original image dimensions.

**Implementation:**
1. Call `preprocess_for_triton(image_bytes)` → `(tensor [3,640,640], orig_w, orig_h)`
2. Send gRPC `InferRequest(model_name="yolov11n_receipt", inputs=[tensor])`
3. Parse output tensor: shape `[-1, 6]` where each row = `[x1, y1, x2, y2, conf, class_id]`
4. Filter rows: `confidence >= YOLO_CONFIDENCE_THRESHOLD (0.35)`
5. Apply NMS with `iou_threshold=YOLO_NMS_IOU_THRESHOLD (0.5)` on surviving boxes
6. If no boxes survive NMS + threshold → raise `NoReceiptDetectedError`
7. Select highest-confidence surviving box
8. Scale coordinates back to original dimensions
9. Return `(x1, y1, x2, y2)`

**Edge Cases (specific to in-hand mobile photos):**
- **Hand partially covers receipt:** YOLO may detect a partial bounding box. This is acceptable — the crop will include the hand border, but Gemini can still read the text. The confidence score will be lower but should still exceed 0.35.
- **Receipt occupies < 20% of frame:** Very small detection. YOLO confidence may be low. If below threshold → `NoReceiptDetectedError`. Client should re-photograph closer.
- **Multiple detections from NMS:** Can occur if the receipt appears twice in YOLO's output with slightly different boxes. NMS with IoU=0.5 collapses these. Take the highest-confidence surviving box.
- **No detections at all (empty output tensor):** `detections.shape[0] == 0`. Raises `NoReceiptDetectedError("YOLO returned no bounding boxes")`.
- **All detections below threshold (e.g., max confidence = 0.28):** Raises `NoReceiptDetectedError(f"confidence {max_conf:.2f} below threshold {threshold}")`. Common cause: receipt is held at an extreme angle, very poor lighting, or background is visually similar to the receipt (white wall behind white receipt).
- **Triton connection refused:** `TritonUnavailableError`. Check Triton container health and model volume mount.
- **Dynamic batching context:** This function sends one gRPC request per call. Triton's dynamic batching aggregates requests from multiple Workers server-side. The Worker is unaware of batching — it simply sends its request and waits for the response. The batch benefit is fully transparent.

---

### `crop_image(image_bytes, bbox)` — `triton_client.py`

**Signature:**
```python
def crop_image(image_bytes: bytes, bbox: tuple[float, float, float, float]) -> bytes
```

**Purpose:** Applies the detected bounding box plus 5% padding to the original image, producing a tightly cropped receipt photo for Gemini. The 5% padding is important for in-hand photos — YOLO may clip the receipt edges, especially where the hand overlaps the border. Padding recovers this text.

**Returns:** `bytes` — Cropped JPEG.

**Implementation:**
```python
img = PIL.Image.open(BytesIO(image_bytes))
x1, y1, x2, y2 = [int(v) for v in bbox]
pad_x = int((x2 - x1) * 0.05)
pad_y = int((y2 - y1) * 0.05)
x1 = max(0, x1 - pad_x)
y1 = max(0, y1 - pad_y)
x2 = min(img.width, x2 + pad_x)
y2 = min(img.height, y2 + pad_y)
cropped = img.crop((x1, y1, x2, y2))
buf = BytesIO()
cropped.save(buf, format="JPEG", quality=95)
return buf.getvalue()
```

**Edge Cases:**
- **Bbox near image edge:** Padding clamped to image boundaries via `max(0, ...)` and `min(img.width/height, ...)`.
- **Degenerate bbox (`x1 >= x2` or `y1 >= y2`):** Raises `InvalidBboxError`. Should not occur with valid YOLO output.
- **Receipt is curved/rolled (as in sample image):** The crop captures the curved receipt as a flat projection. Gemini handles this well — it sees 2D text regardless of curvature.

---

### `extract_invoice_data(cropped_image_bytes)` — `gemini_client.py`

**Signature:**
```python
@retry(
    stop=stop_after_attempt(2),
    wait=wait_exponential(multiplier=1, min=2, max=4),
    retry=retry_if_exception_type((RateLimitError, ServiceUnavailableError)),
    reraise=True
)
async def extract_invoice_data(cropped_image_bytes: bytes) -> str
```

**Purpose:** Sends the cropped receipt image to Gemini 1.5 Pro with a Vietnamese-aware extraction prompt. Returns the raw string response (may be clean JSON, fenced JSON, or garbage — `validate_extracted_schema` handles all cases). The `@retry` decorator handles transient Gemini failures.

**Prompt (finalized):**
```
You are processing a Vietnamese retail receipt photo.

CRITICAL — Vietnamese number format:
  Periods are THOUSAND separators, NOT decimal points.
  "3.530.000" means 3,530,000 VND — not 3.53.
  Return all monetary amounts as plain integers in VND (e.g. 3530000).

Return ONLY a valid JSON object matching this schema. No markdown, no explanation, no preamble.
Schema: {schema_json}
Set any field not visible in the image to null.
```

**Per-call timeout:** 12 seconds enforced inside the SDK call via `request_options=RequestOptions(timeout=12)`.

**Retry policy:**

| Attempt | Wait before | Max call time | Total elapsed |
|---|---|---|---|
| 1st | 0s | 12s | 12s |
| 2nd (if 429/503) | 2–4s | 12s | 28s |
| Exhausted | — | — | Raises `GeminiExhaustedError` |

**Edge Cases:**
- **HTTP 429 Rate Limit:** At 10,000 req/day over 8 hours ≈ 1 req/8.5s, well within standard Gemini limits. Retries handle burst spikes.
- **HTTP 503 Gemini downtime:** 2 retries. If Google AI is down for > 30s, jobs fail gracefully. Grafana failure rate alert fires within 2 minutes.
- **Empty response:** `response.text` is None or `""`. Raises `EmptyGeminiResponseError`.
- **Markdown-fenced JSON:** e.g., `` ```json\n{...}\n``` ``. Handled downstream in `validate_extracted_schema`.
- **Vietnamese amounts correctly extracted:** The prompt instructs Gemini to return integers. For the sample receipt, "3.530.000" VND should come back as `3530000`. The downstream VND validator in `validate_extracted_schema` is a safety net for cases where Gemini ignores the instruction.
- **Image too small / too blurry:** Gemini will attempt to read text regardless. If text is unreadable, it returns `null` for those fields. This is a SUCCESS with partial data, not a FAILED job.

---

### `validate_extracted_schema(raw_json)` — `schema_parser.py`

**Signature:**
```python
def validate_extracted_schema(raw_json: str) -> InvoiceResult
```

**Purpose:** Parses and validates the raw Gemini string against the strict `InvoiceResult` Pydantic model. Handles markdown fences, extracts JSON from mixed text, and applies the VND number coercion. Last line of defense against hallucinated or malformed data.

**Returns:** `InvoiceResult` — validated Pydantic model instance.

**Implementation:**
```python
def validate_extracted_schema(raw_json: str) -> InvoiceResult:
    # Step 1: Strip markdown fences
    cleaned = re.sub(r"```(?:json)?\s*|\s*```", "", raw_json).strip()

    # Step 2: Extract JSON object if Gemini prepended explanation text
    # e.g., "Here is the extracted data: {...}"
    json_match = re.search(r'\{.*\}', cleaned, re.DOTALL)
    if not json_match:
        raise SchemaValidationError(f"No JSON object found. Raw: {cleaned[:200]}")
    cleaned = json_match.group(0)

    # Step 3: Parse JSON
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise SchemaValidationError(f"Invalid JSON: {e}. Raw: {cleaned[:200]}")

    # Step 4: Pydantic validation (VND coercion happens via validators)
    try:
        return InvoiceResult(**data)
    except ValidationError as e:
        raise SchemaValidationError(f"Schema mismatch: {e}")
```

**Edge Cases:**
- **Gemini wraps JSON in markdown:** `` ```json\n{...}\n``` `` → Step 1 strips fences.
- **Gemini prepends explanation text:** `"Here is the extracted data: {...}"` → Step 2 extracts the JSON object.
- **VND amounts returned with separators despite prompt:** e.g., `"total_amount": "3.530.000"` — Pydantic `@validator(pre=True)` applies `vnd_to_int()` (see §6) to coerce this correctly.
- **Missing required fields:** All `InvoiceResult` fields are `Optional[X] = None`. Pydantic never fails on missing fields — it populates with `null`. This is intentional: partial extraction is a SUCCESS, not a FAILED job.
- **Hallucinated extra fields:** `model_config = ConfigDict(extra='ignore')`. Extra fields silently dropped.
- **Empty string input:** `re.search` finds nothing → `SchemaValidationError`.
- **Gemini returns only `null`:** `json.loads("null")` returns Python `None`. Step 4's `InvoiceResult(**None)` raises `TypeError`. Caught as generic exception → `SchemaValidationError`.

---

## 6. Schema & Models — `src/models/invoice.py`

### `InvoiceResult` (Pydantic Model)

```python
from pydantic import BaseModel, ConfigDict, field_validator
from typing import Optional
from datetime import date
import re

def vnd_to_int(v) -> Optional[int]:
    """
    Converts Vietnamese VND currency strings to integers.
    "3.530.000" → 3530000
    "3,530,000" → 3530000
    3530000     → 3530000  (passthrough)
    "$45.00"    → 45       (fallback for non-VND formats)
    """
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return int(v)
    if isinstance(v, str):
        stripped = v.strip()
        # Vietnamese format: remove periods and commas as thousand separators
        # Then parse what remains
        # Handle "3.530.000" (VND) vs "3.53" (non-VND float)
        # Key insight: VND amounts are always integers — no decimal cents
        digits_only = re.sub(r'[^\d]', '', stripped)
        if digits_only:
            return int(digits_only)
    return None

class LineItem(BaseModel):
    description: Optional[str] = None
    quantity: Optional[float] = None
    unit_price: Optional[int] = None   # VND — always integer
    total: Optional[int] = None        # VND — always integer

    @field_validator('unit_price', 'total', mode='before')
    @classmethod
    def coerce_vnd(cls, v): return vnd_to_int(v)

class InvoiceResult(BaseModel):
    model_config = ConfigDict(extra='ignore')  # silently drop hallucinated fields

    # Store identity
    store_name: Optional[str] = None         # e.g. "BÁCH HÓA XANH"
    invoice_number: Optional[str] = None     # e.g. "OV10487650530426Z"
    invoice_date: Optional[date] = None      # e.g. "2025-05-02"
    invoice_time: Optional[str] = None       # e.g. "12:41" (Vietnamese receipts often include time)

    # Parties
    vendor_name: Optional[str] = None        # chain name
    vendor_address: Optional[str] = None
    customer_phone: Optional[str] = None     # masked: "******3173" — do not unmask
    cashier_id: Optional[str] = None

    # Line items
    line_items: Optional[list[LineItem]] = None

    # Financial totals (all VND integers)
    subtotal: Optional[int] = None
    discount_amount: Optional[int] = None
    tax_amount: Optional[int] = None
    total_amount: Optional[int] = None       # "Tổng thành tiền" / "Thanh toán"
    amount_paid: Optional[int] = None        # "Tổng tiền thu khách hàng"
    change_given: Optional[int] = None

    # Currency (almost always VND for Vietnamese receipts)
    currency: Optional[str] = None           # ISO 4217: "VND"

    # Payment
    payment_method: Optional[str] = None     # "cash", "card", "QR"
    payment_reference: Optional[str] = None  # e.g. QR transaction ID

    # Metadata
    receipt_code: Optional[str] = None       # "Mã tra cứu hóa đơn"
    vat_invoice_url: Optional[str] = None    # "hddt.bachhoaxanh.com"
    notes: Optional[str] = None

    @field_validator('subtotal', 'discount_amount', 'tax_amount',
                     'total_amount', 'amount_paid', 'change_given', mode='before')
    @classmethod
    def coerce_vnd_fields(cls, v): return vnd_to_int(v)

    @field_validator('invoice_date', mode='before')
    @classmethod
    def parse_vietnamese_date(cls, v):
        """Handle Vietnamese date formats: DD/MM/YYYY, YYYY-MM-DD."""
        if isinstance(v, str):
            for fmt in ('%d/%m/%Y', '%Y-%m-%d', '%d-%m-%Y'):
                try:
                    from datetime import datetime
                    return datetime.strptime(v, fmt).date()
                except ValueError:
                    continue
        return v
```

**Sample: parsing the uploaded receipt**

```
Input image: Bách Hóa Xanh receipt, 02/05/2025

Expected InvoiceResult:
{
  "store_name": "BÁCH HÓA XANH",
  "invoice_number": "OV10487650530426Z",
  "invoice_date": "2025-05-02",
  "invoice_time": "12:41",
  "line_items": [
    {
      "description": "thùng 24 lon bia heineken silver 250ml",
      "quantity": 10,
      "unit_price": 353000,
      "total": 3530000
    },
    {
      "description": "quà tặng: phí giao hàng bách hóa xanh",
      "quantity": 1,
      "unit_price": 0,
      "total": 0
    }
  ],
  "total_amount": 3530000,
  "amount_paid": 3530000,
  "currency": "VND",
  "receipt_code": "36092E3413",
  "vat_invoice_url": "hddt.bachhoaxanh.com",
  "customer_phone": "******3173"
}
```

---

## 7. Background Tasks

### `ensure_buckets_exist()` — `init` container only (v2.0)

**Signature:**
```python
async def ensure_buckets_exist() -> None
```

**Purpose:** Creates `invoices` and `failed-invoices` MinIO buckets if they don't exist. Runs **once** in the `init` Docker Compose service before API and Workers start. Prevents `BucketNotFoundError` on first deployment.

**v2.0 change:** Removed from API and Worker startup. Only the `init` container calls this. Eliminates 4 redundant calls per deploy.

---

### `run_zombie_sweep()` — APScheduler, every 5 minutes (one instance per Worker)

Calls `db.mark_zombie_jobs_failed()`, logs results, updates `ocr_zombie_jobs_swept_total` Prometheus counter. See §4 for full implementation.

---

## 8. Custom Exception Hierarchy

```
OCRSystemError (base)
│
├── IngressError
│   ├── StorageUnavailableError    # MinIO/Postgres/Redis offline at API → HTTP 503
│   └── ResultTimeoutError         # wait_for_result exceeded 60s → HTTP 504
│
├── PipelineError
│   ├── InvalidImageError          # PIL cannot decode → FAILED (no AI cost)
│   ├── NoReceiptDetectedError     # YOLO confidence < 0.35 → FAILED
│   ├── InvalidBboxError           # Degenerate bounding box → FAILED
│   ├── TritonUnavailableError     # gRPC connection refused → FAILED
│   ├── ModelNotReadyError         # Triton model not loaded → FAILED + critical alert
│   ├── GeminiExhaustedError       # 2 retries exhausted → FAILED
│   ├── EmptyGeminiResponseError   # Gemini returned nothing → FAILED
│   └── SchemaValidationError      # Pydantic rejected Gemini output → FAILED
│
└── StorageError
    ├── MinioConnectionError       # Upload/download/delete connection failure
    ├── BucketNotFoundError        # Bucket doesn't exist (init container failure)
    ├── CorruptedDownloadError     # Byte length mismatch on download
    ├── DBConnectionError          # Postgres connection failure
    └── RedisConnectionError       # Redis connection failure
```

**Exception → HTTP code mapping (API layer):**

| Exception | HTTP Code | When |
|---|---|---|
| `StorageUnavailableError` | 503 | MinIO/Postgres/Redis at ingress |
| `ResultTimeoutError` | 504 | 60s elapsed |
| `PipelineError` (any subclass) | 422 | Worker reports `success=False` |
| `RedisConnectionError` at ingress | 503 | Redis unavailable |

---

## 9. Function Dependency Graph

```
POST /predict
└── generate_job_id()
└── minio.upload_file()
└── db.create_job_record()
└── redis.push_to_queue()
└── redis.wait_for_result(timeout=60)         ← blocks here

                    [Worker — one of 4]
                    redis.pop_from_queue()
                    └── execute_task_lifecycle()
                        └── db.update_job_status(PROCESSING)
                        └── minio.download_file()
                        └── image_processor.validate_and_orient_image()
                        └── triton_client.detect_receipt_bounding_box()
                               └── preprocess_for_triton()
                               └── [gRPC → Triton dynamic batch]
                               └── apply_nms()
                        └── triton_client.crop_image()
                        └── gemini_client.extract_invoice_data()
                               └── [@retry: up to 2 attempts, 12s each]
                        └── schema_parser.validate_extracted_schema()
                               └── vnd_to_int() [per monetary field]
                               └── parse_vietnamese_date()
                        └── [SUCCESS path]
                            └── db.update_job_status(SUCCESS)
                            └── redis.publish_result(success=True)   ← FIRST
                            └── minio.delete_file()                  ← AFTER
                        └── [FAILED path]
                            └── db.update_job_status(FAILED)
                            └── redis.publish_result(success=False)
                            └── minio.move_to_failed()

GET /health  → {"status": "ok"}
GET /metrics → Prometheus text

Background (every 5 min, per Worker):
└── run_zombie_sweep()
    └── db.mark_zombie_jobs_failed()   ← sweeps PROCESSING (>15min) AND PENDING (>30min)
```
