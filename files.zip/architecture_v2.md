# Invoice OCR System — Full Architecture Specification
**Version:** 2.0.0 | **Capacity Target:** 10,000 invoices/day | **Pattern:** Synchronous Producer-Consumer
**Image Type:** Mobile phone photos of Vietnamese retail receipts (in-hand, real-world background)

---

## Table of Contents
1. [System Overview](#1-system-overview)
2. [Design Decisions Log](#2-design-decisions-log)
3. [Capacity & Traffic Model](#3-capacity--traffic-model)
4. [Component Architecture](#4-component-architecture)
5. [Data Flow & Sequence](#5-data-flow--sequence)
6. [Triton Dynamic Batching](#6-triton-dynamic-batching)
7. [Infrastructure & Deployment](#7-infrastructure--deployment)
8. [Observability & Metrics](#8-observability--metrics)
9. [Fault Tolerance & Recovery Matrix](#9-fault-tolerance--recovery-matrix)
10. [Security Boundaries](#10-security-boundaries)
11. [Configuration Reference](#11-configuration-reference)

---

## 1. System Overview

### 1.1 Purpose
A stateless invoice OCR pipeline that accepts raw mobile phone photos of Vietnamese retail receipts, extracts structured financial data using a YOLO + Gemini AI pipeline, and returns a validated `InvoiceResult` JSON payload synchronously to the caller via a **single `POST /predict` endpoint**.

### 1.2 Architecture Pattern
**Synchronous Producer-Consumer with RPC-over-Redis. Single unified endpoint. No fallback polling.**

The client calls `POST /predict` once and receives the final JSON response in the same connection — no secondary polling endpoint is needed. This is achieved by extending the API timeout to 60 seconds (well above the p99 pipeline time) and running 4 parallel Worker containers so queue wait time approaches zero even at peak burst. The `GET /predict/{job_id}` fallback from v1.0 has been removed entirely.

```
┌──────────────────────────────────────────────────────────────────────┐
│  CLIENT                                                              │
│  POST /predict (image) ────────────────────── ◄── JSON response     │
│  GET /health   GET /metrics                                          │
└──────────────────────────┬───────────────────────────────────────────┘
                           │
┌──────────────────────────▼───────────────────────────────────────────┐
│  INGRESS LAYER (FastAPI)                                             │
│  POST /predict → upload → create record → enqueue → wait(60s) → JSON│
│  GET  /health  → {"status":"ok"}                                     │
│  GET  /metrics → Prometheus text                                     │
└──────────────┬───────────────────────────────────────────────────────┘
               │
    ┌──────────▼──────────┐   ┌──────────────┐
    │  MinIO (Blob)        │   │  PostgreSQL   │
    │  invoices/           │   │  jobs table   │
    │  failed_invoices/    │   │  (audit log)  │
    └──────────────────────┘   └──────────────┘
               │
    ┌──────────▼──────────────────────────────┐
    │  Redis                                   │
    │  List: ocr_tasks  (FIFO job queue)       │
    │  List: result_<id> (RPC return, TTL 90s) │
    └──────────────────┬──────────────────────┘
                       │  BRPOP (4 workers compete)
        ┌──────────────┼──────────────┬──────────────┐
        ▼              ▼              ▼              ▼
   ┌─────────┐   ┌─────────┐   ┌─────────┐   ┌─────────┐
   │Worker 1 │   │Worker 2 │   │Worker 3 │   │Worker 4 │
   └────┬────┘   └────┬────┘   └────┬────┘   └────┬────┘
        └──────────────┴─────────────┴──────────────┘
                                │  gRPC (dynamically batched)
    ┌───────────────────────────▼───────────────────────┐
    │  Triton Inference Server                           │
    │  Model: YOLOv11n (CPU) — dynamic batching ON      │
    │  Max batch: 4  |  Queue delay: 50ms               │
    └───────────────────────────┬───────────────────────┘
                                │
    ┌───────────────────────────▼───────────────────────┐
    │  Google Gemini 1.5 Pro API                        │
    │  Retries: 2× exponential  |  Per-call cap: 12s   │
    └───────────────────────────────────────────────────┘
```

---

## 2. Design Decisions Log

Every deliberate architectural choice, documented to prevent re-litigation during code review.

| # | Decision | Rationale |
|---|---|---|
| 1 | **Single endpoint: `POST /predict` only. `GET /predict/{id}` removed.** | Client sends an image, receives JSON in one call. The v1.0 fallback GET existed solely because the 25s timeout was too tight. With 4 workers + 60s timeout, p99 pipeline time is well under 45s. The second endpoint is unnecessary complexity. |
| 2 | **API timeout 25s → 60s** | Gemini retry budget (2 retries × 12s call + backoff) can consume ~26s in the worst case. 25s was dangerously tight. 60s provides 14–26s headroom above the realistic p99. |
| 3 | **4 Worker containers** | One worker handles ~3,600 jobs/day at p50=8s. 4 workers handle ~14,400/day — 44% above the 10,000 target. |
| 4 | **Triton dynamic batching enabled** | At burst (3 req/s), 4 workers frequently send YOLO inference requests within 50ms of each other. Triton batches these into a single forward pass, cutting per-job YOLO latency from ~4s to ~1.5s at batch=4. |
| 5 | **`publish_result()` called BEFORE `delete_file()` in SUCCESS path** | **Bug fix from v1.0.** MinIO deletion is non-critical cleanup. If it throws, the client result must already be published. Cleanup must never block the return path. |
| 6 | **Gemini retries: 3 attempts → 2 attempts, max wait 10s → 4s** | 3 retries could consume 15 + (2+4+10) = 31s of Gemini time alone. 2 retries with 4s max backoff = max 26s. Fits the 60s budget with room to spare. |
| 7 | **python-magic removed from API layer** | Redundant with PIL validation in the Worker. MIME detection is unreliable (spoofable via magic bytes). PIL is the authoritative validator. API validates file size only. |
| 8 | **`ocr_timeout_total` metric removed** | Fully redundant with `ocr_requests_total{status="timeout"}`. One counter with a label is the Prometheus standard. |
| 9 | **`ensure_buckets_exist()` moved to Docker Compose `init` container** | v1.0 had API + all 4 Workers call this on startup = 5 redundant calls per deploy. A single init container runs once before any service starts. |
| 10 | **Zombie sweep now targets both `PROCESSING` and stale `PENDING`** | v1.0 only swept PROCESSING. If Redis goes down between `push_to_queue()` and Worker BRPOP, jobs remain PENDING forever. Now PENDING jobs older than 30 minutes are also swept to FAILED. |
| 11 | **VND number format handling added to schema parser** | Sample receipt uses Vietnamese number formatting: periods as thousand separators ("3.530.000" = 3,530,000 VND). Standard float coercion misparses this. A dedicated VND parser is required. |
| 12 | **YOLO confidence threshold lowered: 0.45 → 0.35** | In-hand mobile photos with cluttered backgrounds (hands, grocery shelves) produce lower and more variable confidence scores than clean flatbed scans. 0.35 retains valid detections that 0.45 would incorrectly reject. |
| 13 | **Gemini prompt explicitly declares Vietnamese language and VND number format** | Without explicit instruction, Gemini interprets "3.530.000" as 3.53 (Western decimal). The prompt must specify that periods are thousand separators in Vietnamese receipts. |

---

## 3. Capacity & Traffic Model

### 3.1 Daily Volume with 4 Workers

| Metric | Value | Derivation |
|---|---|---|
| Target daily volume | 10,000 invoices | Product requirement |
| Single worker max (p50=8s, 8h day) | ~3,600/day | 28,800s ÷ 8s per job |
| **4-worker capacity** | **~14,400/day** | 4 × 3,600 |
| Headroom above target | **44%** | (14,400 − 10,000) / 10,000 |
| Burst peak | 3 req/s | 3× average rate |
| Queue depth at steady burst | 2–4 jobs | 3 arr/s ÷ (4 workers × 0.5 job/s) |

### 3.2 Timeout Budget (Per Request)

```
Total SLA Window: 60 seconds

API side (Producer):
├── File read:                        ~0.1s
├── MinIO upload (600KB internal):    ~0.3s
├── Postgres write (PENDING):         ~0.05s
├── Redis LPUSH:                      ~0.01s
└── Queue wait (4 workers, low load): ~0.1–2s

Worker pipeline (Consumer):
├── MinIO download:                   ~0.3s
├── PIL validate + EXIF orient:       ~0.1s
├── Triton YOLO inference:
│   ├── No batching (solo):           ~3–5s
│   └── Batch=4 at peak:             ~1.5s per job
├── Image crop:                       ~0.05s
├── Gemini call (p50):               ~5–10s
│   └── 1 retry worst case:          +2s wait + 12s call = +14s
└── VND schema parse:                 ~0.05s

Total p50 (no retry):   ~8–12s   → HTTP 200
Total p95 (no retry):   ~18–25s  → HTTP 200
Total p99 (1 retry):    ~32–40s  → HTTP 200
API timeout triggered:  >60s     → HTTP 504 (only if Gemini does 2 max-latency retries)
```

### 3.3 Storage Estimates

| Component | Daily Write | Retention | Notes |
|---|---|---|---|
| MinIO `invoices/` | 10,000 × 600KB ≈ **6 GB/day** | Deleted on SUCCESS | In-hand photos are larger than flat scans |
| MinIO `failed_invoices/` | ~2% × 6GB = **120 MB/day** | Manual purge | Contains PII — restrict access |
| PostgreSQL `jobs` | 10,000 rows × ~1KB = **10 MB/day** | Indefinite | ~3.5 GB/year |
| Redis `result_<id>` | 10,000 × 2KB, TTL 90s | Auto-evicted | Peak ~300KB live |
| Redis `ocr_tasks` | Peak ~4 jobs × 64B | Auto-consumed | < 1KB |

---

## 4. Component Architecture

### 4.1 Ingress API — FastAPI (`src/api/`)

**Runtime:** Python 3.11+, Uvicorn ASGI | **Port:** 8000

#### Endpoints (v2.0 — simplified)

| Method | Path | Handler | Timeout |
|---|---|---|---|
| `GET` | `/health` | `health_check()` | < 10ms |
| `GET` | `/metrics` | Prometheus scrape | < 50ms |
| `POST` | `/predict` | `submit_receipt()` | 60s |

`GET /predict/{job_id}` has been **removed**. `POST /predict` is the complete client interface.

#### Request Lifecycle

```
1.  Read multipart UploadFile
    └─ Size > MAX_UPLOAD_SIZE_MB → HTTP 413 immediately
2.  file_bytes = await file.read()
3.  job_id = generate_job_id()
4.  minio.upload_file(job_id, file_bytes)
    └─ MinIO offline → HTTP 503
5.  db.create_job_record(job_id, PENDING)
    └─ Postgres offline → HTTP 503
6.  redis.push_to_queue(job_id)
    └─ Redis offline → HTTP 503
7.  result = redis.wait_for_result(job_id, timeout=60)
    ├─ success=True  → HTTP 200 + InvoiceResult JSON
    ├─ success=False → HTTP 422 + {"error": "...", "job_id": "..."}
    └─ Timeout       → HTTP 504 + {"error": "Processing timeout", "job_id": "..."}
```

#### HTTP Response Codes

| Code | Trigger |
|---|---|
| `200 OK` | Successful extraction |
| `413 Payload Too Large` | File > 10MB |
| `422 Unprocessable Entity` | Pipeline failed (YOLO, Gemini, schema) |
| `503 Service Unavailable` | MinIO / Postgres / Redis offline |
| `504 Gateway Timeout` | Worker exceeded 60s (rare — Gemini double retry at max latency) |

#### Job State Machine

```
POST /predict → ┌──────────┐
                │  PENDING  │ ← swept after 30 min (new v2.0)
                └────┬─────┘
                     │ Worker BRPOP
                     ▼
                ┌────────────┐
                │ PROCESSING │ ← swept after 15 min
                └──────┬─────┘
                  ┌────┴────┐
                  ▼         ▼
             ┌─────────┐ ┌────────┐
             │ SUCCESS │ │ FAILED │
             └─────────┘ └────────┘
```

---

### 4.2 Redis — Task Queue & RPC (`src/storage/redis_client.py`)

| Key | Type | TTL | Purpose |
|---|---|---|---|
| `ocr_tasks` | List | None (consumed) | FIFO job queue — all 4 workers BRPOP |
| `result_<job_id>` | List | **90 seconds** | Per-job RPC return channel |

TTL is 90s (up from v1.0's 60s) to safely outlast the 60s API timeout. Without TTL: 10,000 orphaned result keys/day × 2KB = ~20MB/day permanent RAM leak.

**Concurrency model:** Redis `BRPOP` is atomic. All 4 workers block on the same list simultaneously; each receives a different job. Natural load balancing with zero configuration.

---

### 4.3 MinIO — Blob Storage (`src/storage/minio_client.py`)

| Bucket | Purpose | Key Format | Lifecycle |
|---|---|---|---|
| `invoices/` | Raw receipt photos during processing | `{job_id}.jpg` | Deleted after SUCCESS |
| `failed_invoices/` | Failed jobs for debugging | `{job_id}.jpg` | Manual review + purge |

At burst: 3 req/s × 60s timeout × 600KB = **108MB** of in-flight images. MinIO externalizes this entirely.

---

### 4.4 PostgreSQL — State Store (`src/storage/postgres_client.py`)

```sql
CREATE TABLE jobs (
    job_id          UUID PRIMARY KEY,
    status          VARCHAR(12) NOT NULL DEFAULT 'PENDING',
    result_payload  JSONB,
    error_log       TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_jobs_sweep ON jobs(status, updated_at)
    WHERE status IN ('PROCESSING', 'PENDING');
```

**Zombie sweep query (v2.0 — covers both PROCESSING and PENDING):**
```sql
UPDATE jobs
SET status    = 'FAILED',
    error_log = CASE
        WHEN status = 'PROCESSING' THEN 'Zombie: worker crashed mid-processing'
        WHEN status = 'PENDING'    THEN 'Zombie: job never picked up (Redis failure?)'
    END,
    updated_at = NOW()
WHERE (
    (status = 'PROCESSING' AND updated_at < NOW() - INTERVAL '15 minutes')
 OR (status = 'PENDING'    AND updated_at < NOW() - INTERVAL '30 minutes')
)
RETURNING job_id, status;
```

---

### 4.5 AI Worker — Orchestration (`src/worker/`)

**4 identical containers.** Each runs `start_worker_loop()` independently, competing on the Redis queue. No inter-worker coordination needed.

#### Corrected SUCCESS Path — Operation Order Fix

```
v1.0 (WRONG)                      v2.0 (CORRECT)
─────────────────────────────────────────────────
db.update(SUCCESS)                 db.update(SUCCESS)
minio.delete_file()    ← blocks    redis.publish_result()  ← unblocks API first
redis.publish_result() ← too late  minio.delete_file()     ← cleanup after
```
In v1.0, if `delete_file()` threw an exception, `publish_result()` was never called. The API would block for 60s then 504, even though extraction had succeeded.

#### Full Task Lifecycle

```python
async def execute_task_lifecycle(job_id: str) -> None:
    await db.update_job_status(job_id, 'PROCESSING')
    try:
        image_bytes  = await minio.download_file(job_id)
        oriented     = image_processor.validate_and_orient_image(image_bytes)
        bbox         = triton_client.detect_receipt_bounding_box(oriented)
        cropped      = triton_client.crop_image(oriented, bbox)
        raw_json     = await gemini_client.extract_invoice_data(cropped)
        result       = schema_parser.validate_extracted_schema(raw_json)

        await db.update_job_status(job_id, 'SUCCESS', result.dict())
        await redis.publish_result(job_id, result.dict(), success=True)  # ← FIRST
        await minio.delete_file(job_id)                                   # ← AFTER

    except Exception as e:
        await db.update_job_status(job_id, 'FAILED', error_log=traceback.format_exc())
        await redis.publish_result(job_id, str(e), success=False)
        await minio.move_to_failed(job_id)
```

---

### 4.6 Gemini 1.5 Pro — Revised Retry Policy

**Model:** `gemini-1.5-pro` (env `GEMINI_MODEL`)

| Attempt | Trigger | Wait | Max call time |
|---|---|---|---|
| 1st | Initial | 0s | 12s |
| 2nd | HTTP 429 or 503 | 2–4s | 12s |
| Exhausted | — | — | Raises `GeminiExhaustedError` |

**Worst-case total:** 12s + 4s + 12s = **28s** — fits the 60s budget.

#### Vietnamese Receipt Prompt

```
You are processing a Vietnamese retail receipt photo.

CRITICAL — Vietnamese number format:
  Periods are THOUSAND separators, NOT decimal points.
  "3.530.000" means 3,530,000 VND — not 3.53.
  Return all monetary amounts as plain integers in VND (e.g. 3530000).

Return ONLY a valid JSON object matching this schema. No markdown, no explanation.
Schema: {schema_json}
Set any field not visible in the image to null.
```

---

## 5. Data Flow & Sequence

### 5.1 Happy Path

```
Client       FastAPI     MinIO    Postgres   Redis     Worker     Triton   Gemini
  │            │           │          │         │          │          │        │
  ├─POST──────►│           │          │         │          │          │        │
  │            ├─upload───►│          │         │          │          │        │
  │            ├─create────────────── ►         │          │          │        │
  │            ├─LPUSH──────────────────────── ►│          │          │        │
  │            ├─BRPOP(wait 60s)───────────────►│          │          │        │
  │            │           │          │         │◄─BRPOP───┤          │        │
  │            │           │          │         │          ├─download─►        │
  │            │           │          │         │          ├─validate+orient   │
  │            │           │          │         │          ├─gRPC────────────► │
  │            │           │          │         │          │◄─bbox─────────────│
  │            │           │          │         │          ├─crop              │
  │            │           │          │         │          ├─Gemini──────────────────►│
  │            │           │          │         │          │◄─JSON───────────────────│
  │            │           │          │         │          ├─parse schema      │
  │            │           │          ├─SUCCESS─────────── ►         │        │
  │            │           │          │         │◄─publish_result──── ┤        │
  │            │◄─BRPOP─────────────────────────┤          │          │        │
  │◄─HTTP 200──┤           │◄─delete──┤         │          │          │        │
```

### 5.2 YOLO Rejection Path (in-hand photo, cluttered background)

```
Worker:
  validate_and_orient_image() → OK (PIL decodes successfully)
  detect_receipt_bounding_box():
    best confidence = 0.28 < threshold 0.35
    → raises NoReceiptDetectedError

  db.update(FAILED, "YOLO: confidence 0.28 below threshold 0.35")
  redis.publish_result(success=False, "NoReceiptDetectedError: ...")
  minio.move_to_failed(job_id)

FastAPI:
  HTTP 422 {"error": "NoReceiptDetectedError: confidence 0.28 < 0.35", "job_id": "..."}
```

### 5.3 Burst Handling with Triton Dynamic Batching

```
t=0ms:     3 simultaneous POST /predict requests
           Redis queue: [job_003, job_002, job_001]

t=5ms:     Worker 1 pops job_001 → sends gRPC InferRequest to Triton
           Worker 2 pops job_002 → sends gRPC InferRequest to Triton
           Worker 3 pops job_003 → sends gRPC InferRequest to Triton

t=55ms:    Triton batch window closes (50ms elapsed)
           Batch [job_001, job_002, job_003] → single forward pass

t=1900ms:  All 3 receive bbox results simultaneously
           Each worker proceeds to Gemini independently (parallel)

Net YOLO latency per job: ~1.9s (vs 4s each sequential = 12s total)
```

---

## 6. Triton Dynamic Batching

### 6.1 Why This Matters

The image source — **in-hand mobile phone photos of Vietnamese receipts** — means YOLO has real work to do. The receipt is partially obscured by a hand, surrounded by groceries and surfaces, potentially curved. YOLOv11n on CPU takes 3–5s in single-inference mode. At burst with 4 workers simultaneously hitting Triton, dynamic batching collapses 4 serial inferences into 1 batched forward pass.

| Mode | 4 simultaneous jobs | Per-job YOLO time |
|---|---|---|
| No batching | 4 × 4s = 16s total | 4s |
| Batch=4 | ~4.5s total | ~1.1s |
| **Speedup** | **3.5×** | — |

### 6.2 Model Configuration (`config.pbtxt`)

```protobuf
name: "yolov11n_receipt"
platform: "onnxruntime_onnx"
max_batch_size: 4

input [{
  name: "images"
  data_type: TYPE_FP32
  dims: [ 3, 640, 640 ]
}]
output [{
  name: "output0"
  data_type: TYPE_FP32
  dims: [ -1, 6 ]           # [x1, y1, x2, y2, confidence, class_id]
}]

dynamic_batching {
  preferred_batch_size: [ 2, 4 ]
  max_queue_delay_microseconds: 50000  # wait up to 50ms before firing partial batch
}

instance_group [{
  count: 1
  kind: KIND_CPU
}]
```

### 6.3 Pre-processing Contract

All workers must send tensors in exactly this format:

```python
def preprocess_for_triton(image_bytes: bytes) -> tuple[np.ndarray, int, int]:
    img = PIL.Image.open(BytesIO(image_bytes)).convert("RGB")
    orig_w, orig_h = img.size
    img_resized = img.resize((640, 640), PIL.Image.BILINEAR)
    arr = np.array(img_resized, dtype=np.float32) / 255.0  # normalize [0,1]
    arr = arr.transpose(2, 0, 1)                            # HWC → CHW [3,640,640]
    return arr, orig_w, orig_h
```

### 6.4 Post-processing: Scale BBox to Original Dimensions

Triton returns bboxes in 640×640 space. Workers must scale back:

```python
scale_x = orig_w / 640.0
scale_y = orig_h / 640.0
x1, y1, x2, y2 = int(rx1*scale_x), int(ry1*scale_y), int(rx2*scale_x), int(ry2*scale_y)
```

Then add 5% padding (prevents cutting off edge text on curved receipts):
```python
pad_x = int((x2 - x1) * 0.05)
pad_y = int((y2 - y1) * 0.05)
x1, y1 = max(0, x1 - pad_x), max(0, y1 - pad_y)
x2, y2 = min(orig_w, x2 + pad_x), min(orig_h, y2 + pad_y)
```

### 6.5 NMS Before Confidence Check

In-hand photos may produce multiple overlapping detections. Apply NMS before the confidence threshold:

```python
kept_indices = apply_nms(boxes, scores, iou_threshold=YOLO_NMS_IOU_THRESHOLD)
best_box = max(kept_indices, key=lambda i: scores[i])
if scores[best_box] < YOLO_CONFIDENCE_THRESHOLD:
    raise NoReceiptDetectedError(f"confidence {scores[best_box]:.2f} < {YOLO_CONFIDENCE_THRESHOLD}")
```

---

## 7. Infrastructure & Deployment

### 7.1 Docker Compose Services

| Service | Image | CPU | RAM | Ports | Notes |
|---|---|---|---|---|---|
| `init` | `python:3.11-slim` | 0.1 | 64MB | — | Bucket creation + DB migrations. Exits on completion. |
| `api` | `python:3.11-slim` + app | 0.5 | 512MB | 8000 | FastAPI ingress |
| `worker` | `python:3.11-slim` + app | 1.0 each | 1GB each | — | `deploy.replicas: 4` |
| `redis` | `redis:7-alpine` | 0.25 | 256MB | 6379 (internal) | |
| `postgres` | `postgres:15-alpine` | 0.5 | 512MB | 5432 (internal) | |
| `minio` | `minio/minio` | 0.5 | 512MB | 9000, 9001 | 9001 internal only |
| `triton` | `nvcr.io/nvidia/tritonserver:24.x-py3` | **4.0** | **4GB** | 8001 (internal gRPC) | Extra CPU for batched forward pass |
| `prometheus` | `prom/prometheus` | 0.1 | 128MB | 9090 | |
| `grafana` | `grafana/grafana` | 0.1 | 128MB | 3000 | |

**Total:** ~10.5 CPU cores, ~11GB RAM
**Recommended host:** `c5.4xlarge` (16 vCPU, 32GB) — leaves 5.5 vCPU + 21GB for OS and headroom.

> Triton receives 4 CPU cores because ONNX Runtime uses intra-op parallelism internally during the batched forward pass. Underpowering Triton eliminates the batching benefit.

### 7.2 Startup Dependency Chain

```
minio ──────► init ──► api
                   ──► worker (×4)
postgres ──────► init
redis    (no dependencies)
triton   (no dependencies — volume-mounted model)
```

`init` creates buckets and runs `alembic upgrade head`, then exits with code 0.
`api` and `workers` use `depends_on: init: condition: service_completed_successfully`.

### 7.3 Volume Mounts

| Volume | Service | Content |
|---|---|---|
| `postgres_data` | postgres | Job records |
| `minio_data` | minio | Receipt blobs |
| `redis_data` | redis | AOF persistence (optional) |
| `./models` | triton | `yolov11n_receipt/` model repo (`:ro`) |
| `./prometheus.yml` | prometheus | Scrape config |

---

## 8. Observability & Metrics

### 8.1 Prometheus Metrics

| Metric | Type | Labels | Description |
|---|---|---|---|
| `ocr_requests_total` | Counter | `status`: success / pipeline_failed / timeout / storage_error | All POST /predict outcomes |
| `ocr_request_duration_seconds` | Histogram | — | API end-to-end latency. Buckets: 2,5,10,20,30,45,60s |
| `ocr_queue_depth` | Gauge | — | `LLEN ocr_tasks` sampled every 15s |
| `ocr_worker_pipeline_duration_seconds` | Histogram | `stage`: download/validate/yolo/gemini/schema | Per-stage Worker latency |
| `ocr_gemini_retries_total` | Counter | `attempt`: 1/2 | Retry events by attempt |
| `ocr_zombie_jobs_swept_total` | Counter | `from_status`: PROCESSING/PENDING | Recovery events |
| `ocr_storage_errors_total` | Counter | `service`: minio/postgres/redis | Upstream failures |
| `ocr_yolo_rejection_total` | Counter | — | Jobs rejected by YOLO (low confidence) |
| `ocr_triton_batch_size` | Histogram | — | Actual batch sizes executed. Buckets: 1,2,3,4 |

> `ocr_timeout_total` removed. Use `ocr_requests_total{status="timeout"}` instead.

### 8.2 Grafana Panels

**Panel 1 — Request Rate**
Query: `rate(ocr_requests_total[1m])`
Alert: > 5 RPS sustained 5m → capacity warning

**Panel 2 — Queue Depth**
Query: `ocr_queue_depth`
Alert: > 8 for 30s → warning | > 30 for 60s → critical

**Panel 3 — Success Rate**
Query: `rate(ocr_requests_total{status="success"}[5m]) / rate(ocr_requests_total[5m])`
Alert: < 95% for 5m → warning | < 80% → critical

**Panel 4 — Latency Percentiles**
Query p50/p95: `histogram_quantile(0.50|0.95, rate(ocr_request_duration_seconds_bucket[5m]))`
Alert: p95 > 45s → warning (approaching 60s timeout)

**Panel 5 — YOLO Rejection Rate**
Query: `rate(ocr_yolo_rejection_total[5m]) / rate(ocr_requests_total[5m])`
Alert: > 10% for 10m → warning. Expected normal maximum for in-hand mobile photos.

**Panel 6 — Triton Batch Efficiency**
Query: `histogram_quantile(0.50, rate(ocr_triton_batch_size_bucket[5m]))`
Healthy: p50 batch ≥ 2 during peak hours. Alert: p50 = 1 during peak → batching misconfigured.

**Panel 7 — Gemini Retry Rate**
Query: `rate(ocr_gemini_retries_total[5m])`
Alert: > 0.1/s → Gemini rate limiting or degradation

**Panel 8 — Zombie Sweep**
Query: `increase(ocr_zombie_jobs_swept_total[1h])` by `from_status`
Alert: any PROCESSING zombies → worker crash. Any PENDING zombies → Redis instability.

**Panel 9 — Pipeline Stage Latency**
Query: `histogram_quantile(0.95, rate(ocr_worker_pipeline_duration_seconds_bucket[5m]))` by `stage`
Identifies whether YOLO or Gemini is the bottleneck.

### 8.3 Structured Log Format

```json
{
  "ts": "2025-05-02T12:41:00.000Z",
  "level": "INFO",
  "service": "worker",
  "worker_id": "worker-3",
  "job_id": "550e8400-e29b-41d4-a716-446655440000",
  "event": "pipeline_stage_complete",
  "stage": "yolo",
  "duration_ms": 1820,
  "batch_size": 3,
  "confidence": 0.71
}
```

---

## 9. Fault Tolerance & Recovery Matrix

| Failure | Detection | Response | Recovery |
|---|---|---|---|
| MinIO offline at upload | `MinioConnectionError` | HTTP 503 | Client retries POST /predict |
| Postgres offline at create | `DBConnectionError` | HTTP 503 | Client retries POST /predict |
| Redis offline at enqueue | `RedisConnectionError` | HTTP 503 | Client retries POST /predict |
| API timeout (60s) | `ResultTimeoutError` | HTTP 504 | Client retries POST /predict (rare — Gemini double retry worst case) |
| Worker OOM crash mid-job | Job stuck in PROCESSING | Zombie sweep → FAILED after 15min | Client retries POST /predict |
| Redis failure between enqueue and BRPOP | Job stuck in PENDING | Zombie sweep → FAILED after 30min | **New v2.0** — closes v1.0 gap |
| YOLO: receipt not detected | `NoReceiptDetectedError` | HTTP 422 | Image moved to `failed_invoices/`; client re-photographs with better framing |
| YOLO: hand/background occludes receipt | Same as above | HTTP 422 | Client re-photographs |
| Corrupted / non-image file | PIL `InvalidImageError` | HTTP 422 | Client sends valid image |
| Gemini 429 rate limit | Retry up to 2× | Auto-heals | FAILED after 2 retries; client retries |
| Gemini 503 downtime | Retry up to 2× | Auto-heals | Alert fires on failure rate; client retries |
| Gemini hallucinated JSON | `SchemaValidationError` | HTTP 422 | Raw output in `error_log`; prompt improvement |
| Vietnamese amount misparse ("3.530.000") | VND validator catches | — | Handled automatically by custom validator |
| `delete_file()` fails after SUCCESS | Exception caught | Logs warning | Blob remains in MinIO; periodic cleanup cron handles orphaned blobs |
| Client disconnects mid-wait | API BRPOP cancelled | Worker still completes; result TTL 90s → auto-evicted | No action needed |
| Triton unavailable | `TritonUnavailableError` | HTTP 422 | Check Triton container; verify model volume mount |
| Triton batch never groups | Panel 6 shows p50=1 at peak | — | Check `max_queue_delay_microseconds` in config.pbtxt |

---

## 10. Security Boundaries

| Vector | Mitigation |
|---|---|
| Oversized file | `MAX_UPLOAD_SIZE_MB=10` FastAPI middleware — rejected before any processing |
| Job ID enumeration | UUID4 (122-bit entropy) — computationally infeasible to guess |
| Redis / Postgres / MinIO network exposure | Internal Docker bridge only — no external port binding |
| MinIO admin UI | Port 9001 internal only — expose through VPN/bastion if needed |
| Gemini API key | Env var only; never logged; never returned in response |
| YOLO model tampering | Model volume mounted read-only (`:ro`) |
| PII in receipt photos | Deleted from `invoices/` on SUCCESS. `failed_invoices/` contains Vietnamese PII (customer names, phone numbers, purchase history) — restrict bucket access to engineers with need-to-know. |

---

## 11. Configuration Reference

| Variable | Service | Default | Description |
|---|---|---|---|
| `REDIS_URL` | api, worker | `redis://redis:6379` | Redis connection |
| `POSTGRES_DSN` | api, worker, init | `postgresql+asyncpg://...` | Postgres async DSN |
| `MINIO_ENDPOINT` | api, worker, init | `minio:9000` | MinIO host |
| `MINIO_ACCESS_KEY` | all | — | MinIO credentials |
| `MINIO_SECRET_KEY` | all | — | MinIO credentials |
| `MINIO_BUCKET` | api, worker | `invoices` | Primary bucket |
| `MINIO_FAILED_BUCKET` | worker | `failed-invoices` | Failed jobs bucket |
| `GEMINI_API_KEY` | worker | — | Google AI API key |
| `GEMINI_MODEL` | worker | `gemini-1.5-pro` | Model name |
| `GEMINI_CALL_TIMEOUT_SECONDS` | worker | `12` | Per-call hard timeout |
| `GEMINI_RETRY_ATTEMPTS` | worker | `2` | Max retries (reduced from v1.0's 3) |
| `GEMINI_RETRY_MAX_WAIT` | worker | `4` | Max backoff seconds |
| `TRITON_HOST` | worker | `triton:8001` | gRPC endpoint |
| `YOLO_MODEL_NAME` | worker | `yolov11n_receipt` | Triton model name |
| `YOLO_CONFIDENCE_THRESHOLD` | worker | `0.35` | Min confidence (lowered from 0.45 for in-hand photos) |
| `YOLO_NMS_IOU_THRESHOLD` | worker | `0.5` | NMS IoU threshold |
| `API_REQUEST_TIMEOUT` | api | `60` | Seconds before HTTP 504 |
| `MAX_UPLOAD_SIZE_MB` | api | `10` | FastAPI middleware limit |
| `ZOMBIE_SWEEP_INTERVAL_MINUTES` | worker | `5` | APScheduler interval |
| `ZOMBIE_PROCESSING_THRESHOLD_MINUTES` | worker | `15` | PROCESSING → FAILED |
| `ZOMBIE_PENDING_THRESHOLD_MINUTES` | worker | `30` | PENDING → FAILED (new v2.0) |
| `REDIS_RESULT_TTL_SECONDS` | worker | `90` | result_<id> TTL (increased from 60s) |
| `WORKER_ID` | worker | Docker hostname | Injected for log correlation |
